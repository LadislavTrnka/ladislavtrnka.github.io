% run all scripts and create all figures, tables

% Displacement field

NX = 80;
NY = 80;

p = 1e-01; pressure='Pa';
run('Displ_R.m');
run('benchmarkD.m');

p = 1e+06; pressure= 'MPa';
run('Displ_R.m');
run('benchmarkD.m');

NX = 30;
NY = 30;

p = 1e-01; pressure='Pa';
run('Displ_R.m');
run('benchmarkD.m');
run('DisplDirichlet_R.m');
run('benchmarkD.m');
run('DisplDirichlet_M.m');
run('benchmarkD.m');

p = 1e+06; pressure= 'MPa';
run('Displ_R.m');
run('benchmarkD.m');
run('DisplDirichlet_R.m');
run('benchmarkD.m');
run('DisplDirichlet_M.m');
run('benchmarkD.m');

clear all
% Stress field

NX = 40;
NY = 40;

letter='A';
p = 1e-01; pressure='Pa';
run('StressDirichlet_R.m');
run('benchmarkS.m');
run('StressDirichlet_M.m');
run('benchmarkS.m');

letter='A';
p = 1e+06; pressure= 'MPa';
run('StressDirichlet_R.m');
run('benchmarkS.m');
run('StressDirichlet_M.m');
run('benchmarkS.m');

letter='B';
p = 1e-01; pressure='Pa';
run('StressDirichlet_R.m');
run('benchmarkS.m');
run('StressDirichlet_M.m');
run('benchmarkS.m');

letter='B';
p = 1e+06; pressure= 'MPa';
run('StressDirichlet_R.m');
run('benchmarkS.m');
run('StressDirichlet_M.m');
run('benchmarkS.m');

NX = 30;
NY = 30;
p = 1e-01; pressure='Pa';
run('StressDirichlet_LS.m');
run('benchmarkS.m');
p = 1e+06; pressure= 'MPa';
run('StressDirichlet_LS.m');
run('benchmarkS.m');